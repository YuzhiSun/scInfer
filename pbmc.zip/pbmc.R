library(Seurat)
library(SeuratDisk)
library(Matrix)
library(SMAI)
library(SeuratData)
library(uwot)
library(ggrepel)
library(ggplot2)
library(cluster)
library(fossil)
library(batchelor)
library(harmony)
library(rliger)
library(reticulate)
##### rna##
# 读取表达矩阵
expr_matrix <- read.delim("./data/pbmc/rna/matrix.tsv", header = T, row.name = 1)
# 读取观测（细胞）信息
obs_info <- read.delim("./data/pbmc/rna/barcodes.tsv", header = TRUE, row.names = 1)  # 设第一列是行名
# 读取变量（基因）信息
var_info <- read.delim("./data/pbmc/rna/genes.tsv", header = TRUE)

row.names(var_info) = var_info$gene_symbol  #添加行索引

row.names(expr_matrix) = row.names(var_info) # 添加行名
colnames(expr_matrix) = row.names(obs_info) # 添加列名
# 创建 Seurat 对象
citeseq_seurat_object <- CreateSeuratObject(counts = expr_matrix, project = "citeseq")
row.names(citeseq_seurat_object@assays$RNA@layers$counts) = row.names(var_info) # 添加行名
colnames(citeseq_seurat_object@assays$RNA@layers$counts) = row.names(obs_info) # 添加列名
# 添加观测和变量的元数据
citeseq_seurat_object@meta.data <- obs_info
rownames(citeseq_seurat_object@meta.data) <- colnames(expr_matrix)  # 确保行名匹配

# 计数矩阵需要进行预处理

citeseq_seurat_object = NormalizeData(citeseq_seurat_object)
citeseq_seurat_object = FindVariableFeatures(citeseq_seurat_object)

##### scms #####
# 读取表达矩阵
expr_matrix <- read.delim("./data/pbmc/scms/matrix.tsv", header = T, row.name = 1)

# 读取观测（细胞）信息
obs_info <- read.delim("./data/pbmc/scms/barcodes.tsv", header = TRUE, row.names = 1)  # 设第一列是行名
# 读取变量（基因）信息
var_info <- read.delim("./data/pbmc/scms/genes.tsv", header = TRUE)

row.names(var_info) = var_info$gene_name  #添加行索引

row.names(expr_matrix) = row.names(var_info) # 添加行名
colnames(expr_matrix) = row.names(obs_info) # 添加列名
# scms的数据从获取来之后就是归一化的，需要重新minmax缩放，防止出现负值
expr_matrix <- apply(expr_matrix, 2, function(x) {
  (x - min(x)) / (max(x) - min(x))
})

# 创建 Seurat 对象
scms_seurat_object <- CreateSeuratObject(counts = expr_matrix, project = "scms")

# 添加观测和变量的元数据
scms_seurat_object@meta.data <- obs_info
rownames(scms_seurat_object@meta.data) <- colnames(expr_matrix)  # 确保行名匹配

row.names(scms_seurat_object@assays$RNA@layers$counts) = row.names(var_info) # 添加行名
colnames(scms_seurat_object@assays$RNA@layers$counts) = row.names(obs_info) # 添加列名


scms_seurat_object = NormalizeData(scms_seurat_object)
scms_seurat_object = FindVariableFeatures(scms_seurat_object, nfeatures = 500)



celltype_citeseq = citeseq_seurat_object@meta.data$celltype
data_citeseq = as.matrix(citeseq_seurat_object@assays$RNA@layers$counts)

celltype_scms = scms_seurat_object@meta.data$celltype
data_scms = as.matrix(scms_seurat_object@assays$RNA@layers$counts)



features <- SelectIntegrationFeatures(object.list = list(citeseq_seurat_object, scms_seurat_object))
data.X1 = data_citeseq[match(features,rownames(data_citeseq)),]
ct.X1 = celltype_citeseq
data.X2 = data_scms[match(features,rownames(data_scms)),]
ct.X2 = celltype_scms


all.RNA = cbind(data.X1, data.X2)
dim(all.RNA)
meta.data=data.frame(cell_type = factor(c(ct.X1,ct.X2)),
                     method = factor(c(rep("data1",length(ct.X1)), rep("data2",length(ct.X2)))))
row.names(meta.data)=c(colnames(all.RNA))
all.data <- CreateSeuratObject(counts = all.RNA, project = "pbmc",meta.data = meta.data)
all.data <- SplitObject(all.data, split.by = "method")
all.data <- lapply(X = all.data, FUN = function(x) {
  x <- FindVariableFeatures(x, selection.method = "vst", nfeatures = 400)
  x <- NormalizeData(x)
})
features <- SelectIntegrationFeatures(object.list = all.data)
data.anchors <- FindIntegrationAnchors(object.list = all.data, anchor.features = features)
data.combined <- IntegrateData(anchorset = data.anchors)
dim(data.combined@assays$integrated@data)
data1=as.matrix(data.combined@assays$integrated@data[,1:length(ct.X1)])
data2=as.matrix(data.combined@assays$integrated@data[,(length(ct.X1)+1):(length(ct.X1)+length(ct.X2))])
data.X1.smai = as.matrix(all.data$data1@assays$RNA$data)
data.X2.smai = as.matrix(all.data$data2@assays$RNA$data)
data.X1.smai = data.X1.smai[match(features,rownames(data.X1.smai)),]
data.X2.smai = data.X2.smai[match(features,rownames(data.X2.smai)),]

############## SMAI
#identify maximal correspondence subsets
mnn.out = findMutualNN(t(data1),t(data2), k1=20)
prop.align.par = min(c(length(unique(mnn.out$first))/dim(data1)[2],
                       length(unique(mnn.out$second))/dim(data2)[2]))
prop.align.par

#start SMAI
set.seed(3)
out.smai <- align(data.X1.smai, data.X2.smai, dir.map = "auto", denoise="scree",
                  sel1=unique(mnn.out$first),  sel2=unique(mnn.out$second),
                  t=5, knn=30, r.max=200, cutoff = 1.001, cutoff.t=3.0,
                  prop.align = 0.01
)

out.smai$p.value#p-value from SMAI-test
#[1] 0.4394436
meta_data=data.frame(cell_type = factor(c(ct.X1,ct.X2)),
                     batch = factor(c(rep("citeseq",length(ct.X1)), rep("scms",length(ct.X2)))))

colnames(out.smai$data1.integrate) = colnames(data_citeseq)
data.int = t(cbind(out.smai$data1.integrate,out.smai$data2.integrate))

out=matrix(ncol=3,nrow=6)
set.seed(10)
out0=assess(data.int, meta_data)
out[1,] = unlist(out0)

f.out = matrix(ncol=6,nrow=6)
f.out[1,1:3] = faithful(data.int[1:length(ct.X1),], t(data.X1.smai))
f.out[1,4:6] = faithful(data.int[-c(1:length(ct.X1)),], t(data.X2.smai))

out.citeseq = as.data.frame(out.smai$data1.integrate)
out.scms = as.data.frame(out.smai$data2.integrate)
# write result
write.csv(out.citeseq, "./data/pbmc/smai_rna_feas.csv")
write.csv(out.scms, "./data/pbmc//smai_scms_feas.csv")

# plot result
data.int = t(cbind(out.smai$data1.integrate,out.smai$data2.integrate))
umap.out = umap(data.int, n_neighbors = 50, metric = "cosine", spread = 5)
data.plot = data.frame(UMAP1 = c(umap.out[,1]), UMAP2= c(umap.out[,2]),
                       cell_type = factor(meta_data$cell_type), batch = factor(meta_data$batch))
p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = cell_type)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#9*7 under pdf
pdf(file = "Pos1_SMAI1.pdf", width=8,height=6)
p1
dev.off()

p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = batch, alpha=0.5)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#7*6 under pdf
pdf(file = "Pos1_SMAI2.pdf", width=7,height=6)
p1
dev.off()


############Seurat
all.RNA = cbind(data.X1,data.X2)
dim(all.RNA)
meta.data= data.frame(method = c(rep("citeseq", dim(data.X1)[2]), rep("scms", dim(data.X2)[2])))
row.names(meta.data)=c(colnames(data.X1), colnames(data.X2))
all.data <- CreateSeuratObject(counts = all.RNA, project = "myeloid", meta.data = meta.data)
all.data <- SplitObject(all.data, split.by = "method")
all.data <- lapply(X = all.data, FUN = function(x) {
  x <- FindVariableFeatures(x, selection.method = "vst", nfeatures = 450)
  x <- NormalizeData(x)
})
# select features that are repeatedly variable across datasets for integration
features <- SelectIntegrationFeatures(object.list = all.data)
data.anchors <- FindIntegrationAnchors(object.list = all.data, anchor.features = features)
data.combined <- IntegrateData(anchorset = data.anchors)
dim(data.combined@assays$integrated@data)
data1.seurat=as.matrix(data.combined@assays$integrated@data[,1:length(ct.X1)])
data2.seurat=as.matrix(data.combined@assays$integrated@data[,(length(ct.X1)+1):(length(ct.X1)+length(ct.X2))])

data.int.seurat = t(cbind(data1.seurat,data2.seurat))
# write result
write.csv(data1.seurat, "./data/pbmc/seurat_rna_feas.csv")
write.csv(data2.seurat, "./data/pbmc/seurat_scms_feas.csv")
f.out[2,1:3] = faithful(data.int.seurat[1:length(ct.X1),], t(data.X1.smai))
f.out[2,4:6] = faithful(data.int.seurat[-c(1:length(ct.X1)),], t(data.X2.smai))

out0=assess(data.int.seurat, meta_data)
out[2,] = unlist(out0)
meta_data=data.frame(cell_type = factor(c(ct.X1,ct.X2)),
                     batch = factor(c(rep("citeseq",length(ct.X1)), rep("scms",length(ct.X2)))))
data.int = t(cbind(data1.seurat,data2.seurat))
umap.out = umap(data.int, n_neighbors = 50, metric = "cosine", spread = 5)
data.plot = data.frame(UMAP1 = c(umap.out[,1]), UMAP2= c(umap.out[,2]),
                       cell_type = factor(meta_data$cell_type), batch = factor(meta_data$batch))
p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = cell_type)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#9*7 under pdf
pdf(file = "Pos1_seurat1.pdf", width=8,height=6)
p1
dev.off()

p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = batch, alpha=0.5)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#7*6 under pdf
pdf(file = "Pos1_seurat2.pdf", width=7,height=6)
p1
dev.off()


######################## Harmony
all.RNA = cbind(data.X1,data.X2)
meta.data= data.frame(method = c(rep("rna", dim(data.X1)[2]), rep("scms", dim(data.X2)[2])))
row.names(meta.data)=c(colnames(data.X1), colnames(data.X2))
all.data <- CreateSeuratObject(counts = all.RNA, project = "breast", meta.data = meta.data)
all.data <- NormalizeData(all.data)
all.data <- FindVariableFeatures(all.data, selection.method = "vst", nfeatures = 450)
all.data <- ScaleData(all.data, verbose = FALSE)
all.data <- RunPCA(all.data, pc.genes = all.data@var.genes, npcs = 50, verbose = FALSE)
all.data <- RunHarmony(all.data, "method")
dim(all.data@reductions$harmony@cell.embeddings)
data1.har=t(as.matrix(all.data@reductions$harmony@cell.embeddings[1:length(ct.X1),]))
data2.har=t(as.matrix(all.data@reductions$harmony@cell.embeddings[(length(ct.X1)+1):(length(ct.X1)+length(ct.X2)),]))

# write result
write.csv(data1.har, "./data/pbmc/harmony_rna_feas.csv")
write.csv(data2.har, "./data/pbmc/harmony_scms_feas.csv")
data.int.har = t(cbind(data1.har,data2.har))

f.out[3,1:3] = faithful(data.int.har[1:length(ct.X1),], t(data.X1.smai))
f.out[3,4:6] = faithful(data.int.har[-c(1:length(ct.X1)),], t(data.X2.smai))
out0=assess(data.int.har, meta_data)
out[3,] = unlist(out0)



data.int = data.int.har
umap.out = umap(data.int, n_neighbors = 50, metric = "cosine", spread = 5)
data.plot = data.frame(UMAP1 = c(umap.out[,1]), UMAP2= c(umap.out[,2]),
                       cell_type = factor(meta_data$cell_type), batch = factor(meta_data$batch))
p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = cell_type)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#9*7 under pdf
pdf(file = "Pos1_harmony1.pdf", width=8,height=6)
p1
dev.off()

p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = batch, alpha=0.5)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#7*6 under pdf
pdf(file = "Pos1_harmony2.pdf", width=7,height=6)
p1
dev.off()



################liger
ifnb_liger <- createLiger(list(data1=(data.X1),data2=(data.X2)))
ifnb_liger <- rliger::normalize(ifnb_liger)
ifnb_liger <- selectGenes(ifnb_liger)
ifnb_liger <- scaleNotCenter(ifnb_liger)
ifnb_liger <- optimizeALS(ifnb_liger, k = 3)
ifnb_liger <- quantile_norm(ifnb_liger)
data1.lig=t(ifnb_liger@datasets$data1@H)
data2.lig=t(ifnb_liger@datasets$data2@H)

# write result
write.csv(data1.lig, "./data/pbmc/liger_citeseq_feas.csv")
write.csv(data2.lig, "./data/pbmc/liger_scms_feas.csv")
temp=factor(as.numeric(factor(c(ct.X1,ct.X2))))
names(temp)=names(ifnb_liger@clusters)
sum(names(temp)!=c(colnames(data.X1),colnames(data.X2)))
ifnb_liger@clusters = temp
cluster.results <- runWilcoxon(ifnb_liger, compare.method = "clusters")


data.int.lig = t(cbind(t(data1.lig),t(data2.lig)))
f.out[4,1:3] = faithful(data.int.lig[1:length(ct.X1),], t(data.X1.smai))
f.out[4,4:6] = faithful(data.int.lig[-c(1:length(ct.X1)),], t(data.X2.smai))

out0=assess(data.int.lig, meta_data)
out[4,] = unlist(out0)

data.int = data.int.lig
umap.out = umap(data.int, n_neighbors = 50, metric = "cosine", spread = 5)
data.plot = data.frame(UMAP1 = c(umap.out[,1]), UMAP2= c(umap.out[,2]),
                       cell_type = factor(meta_data$cell_type), batch = factor(meta_data$batch))
p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = cell_type)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#9*7 under pdf
pdf(file = "Pos1_liger1.pdf", width=8,height=6)
p1
dev.off()

p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = batch, alpha=0.5)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#7*6 under pdf
pdf(file = "Pos1_liger2.pdf", width=7,height=6)
p1
dev.off()

#############fastMNN
out.fastmnn = fastMNN(data.X1.smai,data.X2.smai)
data1.fmnn=(as.matrix(assay(out.fastmnn)[,1:length(ct.X1)]))
data2.fmnn=(as.matrix(assay(out.fastmnn)[,(length(ct.X1)+1):(length(ct.X1)+length(ct.X2))]))

# write result
write.csv(data1.fmnn, "./data/pbmc/fastMNN_citeseq_feas.csv")
write.csv(data2.fmnn, "./data/pbmc/fastMNN_scms_feas.csv")
data.int.fmnn = t(cbind(data1.fmnn,data2.fmnn))
f.out[5,1:3] = faithful(data.int.fmnn[1:length(ct.X1),], t(data.X1.smai))
f.out[5,4:6] = faithful(data.int.fmnn[-c(1:length(ct.X1)),], t(data.X2.smai))
out0=assess(data.int.fmnn, meta_data)
out[5,] = unlist(out0)

data.int = data.int.fmnn
umap.out = umap(data.int, n_neighbors = 50, metric = "cosine", spread = 5)
data.plot = data.frame(UMAP1 = c(umap.out[,1]), UMAP2= c(umap.out[,2]),
                       cell_type = factor(meta_data$cell_type), batch = factor(meta_data$batch))
p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = cell_type)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#9*7 under pdf
pdf(file = "Pos1_fastMNN1.pdf", width=8,height=6)
p1
dev.off()

p1 <- ggplot(data.plot, aes(x=UMAP1, y=UMAP2, colour = batch, alpha=0.5)) + geom_point(size = 0.7)
p1 <- p1 +
  theme(axis.text=element_text(size=15,face="bold"),
        axis.title=element_text(size=15,face="bold"),
        legend.key.size = unit(1, 'cm'),
        legend.title = element_text(size=14,face="bold"), #change legend title font size
        legend.text = element_text(size=14,face="bold")) +
  guides(colour = guide_legend(override.aes = list(size=5)))#7*6 under pdf
pdf(file = "Pos1_fastMNN2.pdf", width=7,height=6)
p1
dev.off()

##############SCANORAMA
datasets <- list(t(data.X1.smai),t(data.X2.smai))
genes_list <- list((rownames(data.X1.smai)),(rownames(data.X2.smai)))
reticulate::use_python("/Users/rongma/opt/miniconda3/envs/scanorama/bin/python")
scanorama <- import('scanorama')
integrated.data <- scanorama$integrate(datasets, genes_list)
corrected.data <- scanorama$correct(datasets, genes_list, return_dense=TRUE)
integrated.corrected.data <- scanorama$correct(datasets, genes_list,
                                               return_dimred=TRUE, return_dense=TRUE)
data1.sca=t(integrated.corrected.data[[2]][[1]])
data2.sca=t(integrated.corrected.data[[2]][[2]])
data1.sca=data1.sca[match(rownames(data.X1.smai),integrated.corrected.data[[3]]),]
data2.sca=data2.sca[match(rownames(data.X1.smai),integrated.corrected.data[[3]]),]
data.int.sca = t(cbind(data1.sca,data2.sca))
f.out[6,1:3] = faithful(data.int.sca[1:length(ct.X1),], t(data.X1.smai))
f.out[6,4:6] = faithful(data.int.sca[-c(1:length(ct.X1)),], t(data.X2.smai))
out0=assess(data.int.sca, meta_data)
out[6,] = unlist(out0)
colnames(out)=names(unlist(out0))




